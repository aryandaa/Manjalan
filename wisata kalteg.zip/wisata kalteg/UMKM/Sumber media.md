# Sumber dan keterangan foto UMKM

Foto di beberapa folder merupakan ilustrasi produk atau kegiatan sejenis, bukan dokumentasi usaha yang disebut di nama folder. Foto usaha spesifik tidak tersedia di sumber yang ditemukan.

## Usaha yang diminta

- `Dapur Dayak Kumai Sejahtera/Masakan Dayak.jpg` — foto masakan Dayak oleh Raflinoer32, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Ilustrasi kuliner Dayak, bukan foto terverifikasi dari Dapur Dayak Kumai Sejahtera. [Sumber](https://commons.wikimedia.org/wiki/File:Masakan_Dayak.jpg)
- `Kelotok Wisata Berkah Sungai (Pak Joko)/Tanjung Puting sunset cruise.jpg` — Harri J, [CC BY 2.0](https://creativecommons.org/licenses/by/2.0/). Ilustrasi kapal wisata susur sungai di Tanjung Puting, bukan kelotok milik Pak Joko. [Sumber](https://commons.wikimedia.org/wiki/File:Tanjung_Puting_sunset_cruise.jpg)
- `Kerajinan Anyaman Rotan Dayak Kandui/Kerajinan Dayak Taboyan 150829001.JPG` — Ezagren, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Foto warga Dayak Taboyan menganyam tas rotan di Baok, Barito Utara; bukan dokumentasi usaha Kandui. [Sumber](https://commons.wikimedia.org/wiki/File:Kerajinan_Dayak_Taboyan_150829001.JPG)
- `Warung Terapung Danau Sebangau (Ibu Asnah)/Sebangau River (foto lokasi, bukan warung).jpg` — Trebletree, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Foto Sungai Sebangau sebagai ilustrasi lokasi, bukan foto warung terapung atau usaha Ibu Asnah. [Sumber](https://commons.wikimedia.org/wiki/File:Sebangau_River.jpg)
- `Pusat Kerajinan Getah Nyatu Kahayan/Kerajinan Getah Nyatu.jpg` — Martini Rahman, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Foto kerajinan getah nyatu, bukan dokumentasi pusat usaha tertentu. [Sumber](https://commons.wikimedia.org/wiki/File:Kerajinan_Getah_Nyatu.jpg)

## Contoh UMKM khas Kalteng lainnya

- `Kerajinan Anyaman Rotan Dayak Taboyan/Kerajinan Dayak Taboyan 150829002.JPG` — Ezagren, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Kerajinan Dayak Taboyan di Barito Utara. [Sumber](https://commons.wikimedia.org/wiki/File:Kerajinan_Dayak_Taboyan_150829002.JPG)
- `Kuliner Dayak Juhu Umbut Rotan/Juhu Umbut Rotan Ikan Nila.jpg` — Volstand, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Juhu umbut rotan dengan ikan nila. [Sumber](https://commons.wikimedia.org/wiki/File:Juhu_Umbut_Rotan_Ikan_Nila.jpg)
- `Wadai Kiping Dayak Maanyan/Wadai Kiping.jpg` — Wadaihangit, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Wadai kiping pada Festival Dayak Maanyan Warukin 2025. [Sumber](https://commons.wikimedia.org/wiki/File:Festival_Dayak_Maanyan_Warukin_2025_-_Wadai_Kiping.jpg)
