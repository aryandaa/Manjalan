# Sumber media

Media di folder ini diunduh dari Wikimedia Commons. Periksa halaman sumber dan ketentuan lisensi sebelum menggunakan atau membagikan ulang.

## Taman Nasional Tanjung Puting

- `Orang Utan at Tanjung Puting National Park.jpg` — Charlsmile, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). [Sumber](https://commons.wikimedia.org/wiki/File:Orang_Utan_at_Tanjung_Puting_National_Park.jpg)
- `Sekonyer River, Tanjung Puting National Park.jpg` — Lydia Kristiani, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). [Sumber](https://commons.wikimedia.org/wiki/File:Sekonyer_River,_Tanjung_Puting_National_Park.jpg)
- `Tanjung Puting National Park.jpg` — Jorge Franganillo, [CC BY 2.0](https://creativecommons.org/licenses/by/2.0/). [Sumber](https://commons.wikimedia.org/wiki/File:Tanjung_Puting_National_Park.jpg)
- `Video Tanjung Puting.url` — tautan video “Langka! Lihat Orangutan di Habitat Aslinya! Tinggal di Taman Nasional Tanjung Puting Selama 3 Malam!” oleh Leonardo Edwin di YouTube. Tautan, bukan salinan video. [Tonton](https://www.youtube.com/watch?v=m0EY-GFn6Rc)

## Taman Nasional Sebangau

- `Rumput Rasau Ekosistem Air Hitam Taman Nasional Sebangau.jpg` — Ariesandy0812, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). [Sumber](https://commons.wikimedia.org/wiki/File:Rumput_Rasau_Ekosistem_Air_Hitam_Taman_Nasional_Sebangau.jpg)
- `Sebangau National Park.jpg` — Fuadmi, [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). [Sumber](https://commons.wikimedia.org/wiki/File:Sebangau_National_Park.jpg)
- `Sebangau River.jpg` — Trebletree, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). [Sumber](https://commons.wikimedia.org/wiki/File:Sebangau_River.jpg)
- `Pemandangan Wisata Air Hitam Kereng Bangkirai (20260323 110816).webm` — Gabpzxs, [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/). Video 480p. [Sumber](https://commons.wikimedia.org/wiki/File:Pemandangan_Wisata_Air_Hitam_Kereng_Bangkirai_(20260323_110816).webm)

## Kawasan Wisata Alam Bukit Tangkiling

- `Bukit Tangkiling dari depan Koramil 1016-02 Bukit Batu.jpg` — Gabpzxs, [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/). [Sumber](https://commons.wikimedia.org/wiki/File:Bukit_Tangkiling_dari_depan_Koramil_1016-02%E2%80%94Bukit_Batu_(20260117_103759).jpg)
- `Video Bukit Tangkiling.url` — tautan video “Bukit Tangkiling, Wisata Alam Berbalut Legenda Sangkuriang ala Dayak di Kawasan 9 Bukit Palangkaraya” oleh iTrip ID di YouTube. Tautan, bukan salinan video. [Tonton](https://www.youtube.com/watch?v=rDb-rtI0eIM)

## Ekowisata Danau Gambut Tahai

- `Tahai.jpg` — Fariszal, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). [Sumber](https://commons.wikimedia.org/wiki/File:Tahai.jpg)
- `Video Danau Tahai.url` — tautan video “Danau Tahai Palangka Raya, Keindahan Air Merah dan Hutan Eksotis” oleh iTrip ID di YouTube. Tautan, bukan salinan video. [Tonton](https://www.youtube.com/watch?v=wKKTbggGOj8)

## Istana Kuning Pangkalan Bun

- `Istana Kuning Pangkalan Bun.jpg` — Raflinoer32, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). [Sumber](https://commons.wikimedia.org/wiki/File:Istana_Kuning_Pangkalan_Bun.jpg)
- `Video Istana Kuning.url` — tautan video “WISATA ISTANA KUNING DI PANGKALAN BUN KALIMANTAN TENGAH” di YouTube. Tautan, bukan salinan video. [Tonton](https://www.youtube.com/watch?v=101kZBBjg0c)

## Pantai Ujung Pandaran

- `Pantai Ujung Pandaran.jpg` — Raflinoer32, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). [Sumber](https://commons.wikimedia.org/wiki/File:Pantai_Ujung_Pandaran_(4).jpg)
- `Video Pantai Ujung Pandaran.url` — tautan video “WISATA UJUNG PANDANARAN SURGANYA PANTAI” di YouTube. Tautan, bukan salinan video. [Tonton](https://www.youtube.com/watch?v=C2_oEhF7XGA)

## Rumah Betang Tumbang Gagu

- `Rumah Betang Tumbang Gagu.jpg` — Ministry of Education, Culture, Research, and Technology (Indonesia), public domain. [Sumber](https://commons.wikimedia.org/wiki/File:Rumah_Betang_Tumbang_Gagu_I.jpg)
- `Video Rumah Betang Tumbang Gagu.url` — tautan video “Wisata Rumah Betang Tumbang Gagu” di YouTube. Tautan, bukan salinan video. [Tonton](https://www.youtube.com/watch?v=jAgcfKL4vMU)

## Situs Budaya Dayak Batu Banama & Betang

- `Betang Hapakat.jpg` — Martini Rahman, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Foto rumah betang Dayak; bukan foto khusus Batu Banama. [Sumber](https://commons.wikimedia.org/wiki/File:Betang_Hapakat.jpg)
- `Video Batu Banama.url` — tautan video “Situs Batu Banama Taman Wisata alam Tangkiling Palangkaraya (bagian #1)” di YouTube. Tautan, bukan salinan video. [Tonton](https://www.youtube.com/watch?v=xpJN5d9AsJM)

## Taman Nasional Bukit Baka Bukit Raya

- `Gunung Bukit Raya.jpg` — Pariwisata Kalimantan Tengah, public domain. [Sumber](https://commons.wikimedia.org/wiki/File:Gunung_Bukit_Raya.jpg)
- `Video Bukit Baka Bukit Raya.url` — tautan video “Edisi Lengkap Virtual Tour #7 Taman Nasional Bukit Baka Bukit Raya” di YouTube. Tautan, bukan salinan video. [Tonton](https://www.youtube.com/watch?v=6nXVaayHQJU)

## Kawasan Pesisir Pantai Kubu & Bogam

- `Kawasan Pantai Pesisir Bugam Raya.jpg` — Rasyid Ridha, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). [Sumber](https://commons.wikimedia.org/wiki/File:Kawasan_Pantai_di_Pedesaan_Pesisir_Bugam_Raya_(Kubu,_Teluk_Bogam,_Raya).jpg)
- `Video Pantai Kubu Bogam.url` — tautan video “WISATA PANTAI DI KALIMANTAN TENGAH - Kubu, Teluk Bogam, Keraya, Tanjung Keluang, KOTAWARINGIN BARAT” di YouTube. Tautan, bukan salinan video. [Tonton](https://www.youtube.com/watch?v=PF6AUsv9u4c)
